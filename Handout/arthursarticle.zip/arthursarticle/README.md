## Server

- docker build -t notepad15 .
- docker run -p 80:3000 notepad15
- access the challenge on localhost

## Bot

- Requires puppeteer with latest version of chrome 